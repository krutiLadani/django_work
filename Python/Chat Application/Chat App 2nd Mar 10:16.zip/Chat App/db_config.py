import sqlite3


class Connection:


    def insert_record(self, records):

        try:
            print records[-1]

            str_record = "("
            for record in records:
                if record == records[-1]:
                        str_record += "'" + record + "');"
                else:
                        str_record += "'" + record + "',"

            sql = "INSERT INTO CLIENTS (IP,PORT,TIME,NAME) VALUES " + str_record
            print sql
            conn = sqlite3.connect("UnknownFrnds.db")
            conn.execute(sql)
            conn.commit()
            conn.close()
            print "Record Inserted !"
            return True
        except Exception as e:
            return False
