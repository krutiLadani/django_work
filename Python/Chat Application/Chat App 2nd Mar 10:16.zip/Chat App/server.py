# coding=utf-8
import socket
import time
import pickle
from db_config import Connection

conn = Connection()

host = "0.0.0.0"
port = 5005

clients = {}

s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
s.bind((host, port))
s.setblocking(0)
quitting = False

open_log = open("log.txt", "w+")
open_log.writelines(" ")
open_log.close()

open_user = open("users.txt", "w+")
open_user.writelines("")
open_user.close()

# pickle.dump(time.ctime(time.time())+"\n",open_log,-1)
print "Server Started"
while not quitting:
    try:
        data, addr = s.recvfrom(2012)
        if addr not in clients.keys():

            clients[addr] = data
            open_user = open("users.txt", "a")
            open_user.writelines(clients[addr] + "\n")
            open_user.close()

            data = str(data) + " Δ Joined the room"
            file_data = "IP: " + str(addr[0]) + " PORT: " + str(addr[1]) + ", " + time.ctime(
                time.time()) + " --> " + data
            print file_data
            open_log = open("log.txt", "a")
            open_log.writelines(file_data + "\n")
            open_log.close()
            # pickle.dump(file_data+"\n",open_log,-1)
            for client in clients.keys():
                if addr != client:
                    s.sendto(data, client)
            continue

        data = clients[addr] + " Δ " + str(data)

        file_data = "IP: " + str(addr[0]) + ", PORT: " + str(addr[1]) + ", " + time.ctime(time.time()) + " --> " + data
        print file_data
        open_log = open("log.txt", "a")
        open_log.writelines(file_data + "\n")
        open_log.close()
        # pickle.dump(file_data + "\n", open_log, -1)

        for client in clients.keys():
            if client != addr:
                s.sendto(data, client)

    except KeyboardInterrupt:
        quitting = True
    except:
        pass
s.close()
