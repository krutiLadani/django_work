$('#nickNameModal').on('show.bs.modal', function (event) {
  var button = $(event.enterRoom);
  var modal = $(this);
});
// var user_name = "";
function validateName(){
    var nick_name = document.getElementById('nick-name').value.trim();
    if(!(/\S/.test(nick_name))){
       return false;
    }
    else{
        // user_name = nick_name;
        var jqxhr = $.ajax( {url:"/sendname",
            method:"POST",
            data:{name:nick_name}} )
          .done(function() {

          });
        return true;
    }
}

if (screen.width >= 768){
    openNav()
    function openNav() {
        document.getElementById("mySidenav").style.width = "200px";
         document.getElementById("main").style.marginLeft = "200px";
    }

    /* Set the width of the side navigation to 0 */
    function closeNav() {
        document.getElementById("mySidenav").style.width = "0";
        document.getElementById("main").style.marginLeft = "0";
    }
}
else{
    function openNav() {
        document.getElementById("mySidenav").style.width = "150px";
    }

    /* Set the width of the side navigation to 0 */
    function closeNav() {
        document.getElementById("mySidenav").style.width = "0";
    }
}


 //noinspection JSValidateTypes
$('.msg-window').scrollTop($('.msg-window')[0].scrollHeight);

function send_msg() {
    var msg = document.getElementById("msg").value.trim();
    if(!(/\S/.test(msg))){
        document.getElementById("msg").value = "";
        return false;
    }
    else{
        document.getElementById("msg").value = "";

        var jqxhr = $.ajax( {url:"/sendmsg",
            method:"POST",
            data:{msg:msg}} )
            .done(function() {
            });
    }
}

function print_msg(user_name, msg){
    var ul = document.getElementById("c_ul");
        var li = document.createElement("li");
        li.innerHTML = "<div class='panel panel-default'>" +
                            "<div class='panel-heading'>" + user_name +
                            "</div>" +
                            "<div class='panel-body'>"+ msg +
                            "</div>" +
                        "</div>";
        ul.appendChild(li);
        $('.msg-window').scrollTop($('.msg-window')[0].scrollHeight);

}

function print_user(user_name){
        var ul = document.getElementById("user_ul");
        var li = document.createElement("li");
        li.innerHTML = "<span> &bull; </span> " + user_name;
        ul.appendChild(li);
}
var userArray = [];

window.setInterval(function(){
    var userFlag = 1;
    $.get( "users.txt", function( data ) {
    var resourceContent = data;
    var lines = resourceContent.split("\n");

    len = lines.length;
    for(var i=0;i<len-1;i++){
        for(var j=0; j<userArray.length;j++){
            if(userArray[j]==lines[i]){
                userFlag++;
                break;
            }
        }
        if(userFlag==1){
            print_user(lines[i]);
            userArray.push(lines[i]);
        }
    }
    });
}, 500);


var cur_msg = "";
window.setInterval(function(){
    $.get( "log.txt", function( data ) {
    var resourceContent = data;
    var lines = resourceContent.split("\n");
    len = lines.length;
    for(var i=len-2;i<len;i++){
        var data = lines[i].split(">",2);
        var msg = data[1].split("Δ");
        if(cur_msg != data[0]) {
            print_msg(msg[0], msg[1]);
            cur_msg = data[0];
        }
        else{

        }
    }
    });

    var userFlag = 1;
    $.get( "users.txt", function( data ) {
    var resourceContent = data;
    var lines = resourceContent.split("\n");

    len = lines.length;
    for(var i=0;i<len-1;i++){
        for(var j=0; j<userArray.length;j++){
            if(userArray[j]==lines[i]){
                userFlag++;
                break;
            }
        }
        if(userFlag==1){
            print_user(lines[i]);
            userArray.push(lines[i]);
        }
    }
    });
}, 500);

$("#msg").keypress(function(event) {
    if (event.which == 13) {
        // validate();
        if (!send_msg()){
            return false;
        }
     }
});
