$('#nickNameModal').on('show.bs.modal', function (event) {
  var button = $(event.enterRoom);
  var modal = $(this);
});
// var user_name = "";
function validateName(){
    var nick_name = document.getElementById('nick-name').value.trim();
    if(!(/\S/.test(nick_name))){
       return false;
    }
    else{
        // user_name = nick_name;
        return true;
    }
}

function openNav() {
    document.getElementById("mySidenav").style.width = "250px";
}

/* Set the width of the side navigation to 0 */
function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
}

 //noinspection JSValidateTypes
$('.msg-window').scrollTop($('.msg-window')[0].scrollHeight);

function send_msg() {
    var msg = document.getElementById("msg").value.trim();
    if(!(/\S/.test(msg))){
        document.getElementById("msg").value = ""
        return false;
    }
    else{
        // alert("sdfs"+msg)
        document.getElementById("msg").value = ""

        var ul = document.getElementById("c_ul");
        var li = document.createElement("li");
        li.innerHTML = "<div class='panel panel-default'>" +
                            "<div class='panel-heading'>" + "User Name" +
                            "</div>" +
                            "<div class='panel-body'>"+ msg +
                            "</div>" +
                        "</div>";
        ul.appendChild(li);
        $('.msg-window').scrollTop($('.msg-window')[0].scrollHeight);
        // return true;
    }
}

$("#msg").keypress(function(event) {
    if (event.which == 13) {
        // validate();
        if (!send_msg()){
            return false;
        }
     }
});

function validate_user_name() {

}